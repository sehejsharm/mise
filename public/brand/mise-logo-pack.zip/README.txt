Mise logo pack
==============
mise-logo.svg                      Wordmark, light text (for dark backgrounds)
mise-logo-dark.svg                 Wordmark, dark text (for light backgrounds)
mise-mark.svg                      Mark only (app icon / favicon)
mise-logo-512.png                  Mark, 512x512
mise-logo-*-1024.png               Wordmark PNGs, 1024px wide

Colours: Gold #D4A94F, Navy #060B18, Near-white #EEF2FA
Typeface: Space Grotesk (wordmark, outlined), Inter (text).
Name: "Mise" (never MISE). Parent company: Focus Realm.
Keep clear space around the logo equal to the height of the mark's dot.
